from flask import render_template, url_for, flash, redirect, request, Blueprint
from app import db
from app.models import Reservation, Restaurant  # Załóżmy, że Restaurant jest modelem Twojej restauracji
from flask_login import login_required, current_user
from datetime import datetime, timedelta
from sqlalchemy import extract

reservation_bp = Blueprint('reservation', __name__, template_folder='templates')

@reservation_bp.route('/make_reservation/<int:restaurant_id>', methods=['GET', 'POST'])
@login_required
def make_reservation(restaurant_id):
    restaurant = Restaurant.query.get_or_404(restaurant_id)
    menu1_price = restaurant.menu1_price
    menu2_price = restaurant.menu2_price

    if request.method == 'POST':
        guests = int(request.form.get('guests'))
        menu_choice = request.form.get('menu_choice')
        reservation_date = request.form.get('reservation_date')

        reservation_date_dt = datetime.strptime(reservation_date, '%Y-%m-%dT%H:%M')

        if reservation_date_dt < datetime.now():
            flash('Nie można zarezerwować terminu z przeszłości. Proszę wybrać prawidłową datę.', 'danger')
            return redirect(url_for('reservation.make_reservation', restaurant_id=restaurant_id))

        #if datetime.strptime(reservation_date, '%Y-%m-%dT%H:%M') < datetime.now():
         #   flash('Nie można zarezerwować terminu z przeszłości. Proszę wybrać prawidłową datę.', 'danger')
          #  return redirect(url_for('reservation.make_reservation', restaurant_id=restaurant_id))
        
        if guests > restaurant.capacity:
            flash(f'Przekroczono maksymalną liczbę gości dla tej restauracji ({restaurant.capacity}). Proszę wybrać mniejszą liczbę gości.', 'danger')
            return redirect(url_for('reservation.make_reservation', restaurant_id=restaurant_id))
        
        if guests and menu_choice and reservation_date:
            #reservation_date = datetime.strptime(reservation_date, '%Y-%m-%dT%H:%M')

            #existing_reservation = Reservation.query.filter(
             #   Reservation.restaurant_id == restaurant_id,
              #  Reservation.date == reservation_date
            #).first()

            #if existing_reservation and existing_reservation.is_locked():
             #   flash('Ten termin jest już zarezerwowany.', 'danger')
              #  return redirect(url_for('reservation.make_reservation', restaurant_id=restaurant_id))

            existing_reservation = Reservation.query.filter(
                Reservation.restaurant_id == restaurant_id,
                extract('year', Reservation.date) == reservation_date_dt.year,
                extract('month', Reservation.date) == reservation_date_dt.month,
                extract('day', Reservation.date) == reservation_date_dt.day
            ).first()

            if existing_reservation:
                flash('Ten termin jest już zarezerwowany.', 'danger')
                return redirect(url_for('reservation.make_reservation', restaurant_id=restaurant_id))

            locked_until = datetime.now() + timedelta(minutes=15)

            reservation = Reservation(
                date=reservation_date_dt,
                guests=guests,
                menu_choice=menu_choice,
                user_id=current_user.id,
                restaurant_id=restaurant_id,
                locked_until=locked_until
            )

            # Obliczenie całkowitej ceny na serwerze
            if menu_choice == 'Menu Standard':
                total_price = guests * menu1_price
            elif menu_choice == 'Menu Premium':
                total_price = guests * menu2_price
            else:
                flash('Niepoprawny wybór menu.', 'danger')
                return redirect(url_for('reservation.make_reservation', restaurant_id=restaurant_id))
        
            reservation.total_price = total_price

            reservation.total_price = total_price  # ustawienie obliczonej ceny w obiekcie 
            db.session.add(reservation)
            db.session.commit()

            flash('Rezerwacja została dokonana pomyślnie!', 'success')
            return redirect(url_for('reservation.reservation_confirmation'))

        flash('Wystąpił problem podczas przetwarzania rezerwacji. Proszę spróbować ponownie.', 'danger')
        return redirect(url_for('index'))

    return render_template('make_reservation.html', restaurant=restaurant, menu1_price=menu1_price, menu2_price=menu2_price)

@reservation_bp.route('/request_cancellation/<int:reservation_id>', methods=['POST'])
@login_required
def request_cancellation(reservation_id):
    reservation = Reservation.query.get_or_404(reservation_id)

    if request.method == 'POST':
        if reservation.request_cancellation():
            flash('Twoja prośba o anulowanie rezerwacji została przesłana do właściciela restauracji.', 'success')
        else:
            flash('Nie można przesłać prośby o anulowanie rezerwacji, ponieważ jest ona utworzona w ciągu ostatnich 15 minut.', 'danger')

    return redirect(url_for('reservation.my_reservations'))


@reservation_bp.route('/reservation_confirmation')
def reservation_confirmation():
    return render_template('reservation_confirmation.html')

@reservation_bp.route('/my_reservations')
@login_required
def my_reservations():
    current_time = datetime.utcnow()
    past_reservations = Reservation.query.filter(
        Reservation.user_id == current_user.id,
        Reservation.date < current_time
    ).order_by(Reservation.date.desc()).all()
    
    future_reservations = Reservation.query.filter(
        Reservation.user_id == current_user.id,
        Reservation.date >= current_time
    ).order_by(Reservation.date.asc()).all()
    
    return render_template('my_reservations.html', past_reservations=past_reservations, future_reservations=future_reservations)