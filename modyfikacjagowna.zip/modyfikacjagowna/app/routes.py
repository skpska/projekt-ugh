from flask import render_template, url_for, flash, redirect, request
from app import app, db
from app.decorators import role_required
from app.models import Restaurant, Reservation
from flask_login import login_required, current_user
from datetime import datetime

@app.route('/')
@app.route('/index')
def index():
    if current_user.is_authenticated and current_user.role == 'admin':
        return redirect(url_for('admin.admin_panel'))
    if current_user.is_authenticated and current_user.role == 'owner':
        return redirect(url_for('owner.owner_panel'))
    restaurants = Restaurant.query.all()
    return render_template('index.html', restaurants=restaurants)



