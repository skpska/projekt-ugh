from flask import render_template, url_for, flash, redirect, request, Blueprint
from app import db
from app.models import Reservation, Restaurant  # Załóżmy, że Restaurant jest modelem Twojej restauracji
from flask_login import login_required, current_user
from datetime import datetime, timedelta

reservation_bp = Blueprint('reservation', __name__, template_folder='templates')

@reservation_bp.route('/make_reservation/<int:restaurant_id>', methods=['GET', 'POST'])
@login_required
def make_reservation(restaurant_id):
    restaurant = Restaurant.query.get_or_404(restaurant_id)


    if request.method == 'POST':
        guests = int(request.form.get('guests'))
        menu_choice = request.form.get('menu_choice')
        reservation_date = request.form.get('reservation_date')

        if datetime.strptime(reservation_date, '%Y-%m-%dT%H:%M') < datetime.utcnow():
            flash('Nie można zarezerwować terminu z przeszłości. Proszę wybrać prawidłową datę.', 'danger')
            return redirect(url_for('reservation.make_reservation', restaurant_id=restaurant_id))
        
        if guests > restaurant.capacity:
            flash(f'Przekroczono maksymalną liczbę gości dla tej restauracji ({restaurant.capacity}). Proszę wybrać mniejszą liczbę gości.', 'danger')
            return redirect(url_for('reservation.make_reservation', restaurant_id=restaurant_id))
        
        if guests and menu_choice and reservation_date:
            reservation_date = datetime.strptime(reservation_date, '%Y-%m-%dT%H:%M')

            existing_reservation = Reservation.query.filter(
                Reservation.restaurant_id == restaurant_id,
                Reservation.date == reservation_date
            ).first()

            if existing_reservation and existing_reservation.is_locked():
                flash('Ten termin jest już zarezerwowany.', 'danger')
                return redirect(url_for('index'))

            locked_until = datetime.utcnow() + timedelta(minutes=15)

            reservation = Reservation(
                date=reservation_date,
                guests=guests,
                menu_choice=menu_choice,
                user_id=current_user.id,
                restaurant_id=restaurant_id,
                locked_until=locked_until
            )
            db.session.add(reservation)
            db.session.commit()

            flash('Rezerwacja została dokonana pomyślnie!', 'success')

            return redirect(url_for('reservation.reservation_confirmation'))

        flash('Wystąpił problem podczas przetwarzania rezerwacji. Proszę spróbować ponownie.', 'danger')
        return redirect(url_for('index'))

    return render_template('make_reservation.html', restaurant=restaurant)

@reservation_bp.route('/request_cancellation/<int:reservation_id>', methods=['POST'])
@login_required
def request_cancellation(reservation_id):
    reservation = Reservation.query.get_or_404(reservation_id)

    if request.method == 'POST':
        if reservation.request_cancellation():
            flash('Twoja prośba o anulowanie rezerwacji została przesłana do właściciela restauracji.', 'success')
        else:
            flash('Nie można przesłać prośby o anulowanie rezerwacji, ponieważ jest ona utworzona w ciągu ostatnich 15 minut.', 'danger')

    return redirect(url_for('reservation.my_reservations'))


@reservation_bp.route('/reservation_confirmation')
def reservation_confirmation():
    return render_template('reservation_confirmation.html')

@reservation_bp.route('/my_reservations')
@login_required
def my_reservations():
    reservations = Reservation.query.filter_by(user_id=current_user.id).all()
    return render_template('my_reservations.html', reservations=reservations)
