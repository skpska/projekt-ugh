from app import db
from flask_login import UserMixin
from datetime import datetime
from sqlalchemy import DateTime, func

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), nullable=False, unique=True)
    email = db.Column(db.String(150), nullable=False, unique=True)
    password = db.Column(db.String(150), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='user')

class Restaurant(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    location = db.Column(db.String(200), nullable=False)
    menu1 = db.Column(db.Text, nullable=False)
    menu2 = db.Column(db.Text, nullable=False)
    capacity = db.Column(db.Integer, nullable=False)
    menu1_price = db.Column(db.Float, nullable=False)
    menu2_price = db.Column(db.Float, nullable=False)
    reservations = db.relationship('Reservation', backref='restaurant', lazy=True)

    def __repr__(self):
        return f"Restaurant('{self.name}', '{self.location}', '{self.menu1}', '{self.menu2}', '{self.capacity}, '{self.menu1_price}', '{self.menu2_price}')"

class Reservation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.DateTime, nullable=False)
    guests = db.Column(db.Integer, nullable=False)
    menu_choice = db.Column(db.String(50), nullable=False)
    total_price = db.Column(db.Float, nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    restaurant_id = db.Column(db.Integer, db.ForeignKey('restaurant.id'), nullable=False)
    cancellation_requested = db.Column(db.Boolean, default=False)
    locked_until = db.Column(db.DateTime, nullable=True)
    user = db.relationship('User', backref='reservations')

    def calculate_total_price(self):
        restaurant = Restaurant.query.get(self.restaurant_id)
        if self.menu_choice == 'Menu Standard':
            return self.guests * restaurant.menu1_price
        elif self.menu_choice == 'Menu Premium':
            return self.guests * restaurant.menu2_price
        return 0

    def is_locked(self):
        return self.locked_until is not None and self.locked_until > datetime.now()
    
    def request_cancellation(self):
        if not self.is_locked():
            self.cancellation_requested = True
            db.session.commit()
            return True
        return False
    
    def confirm_cancellation(self):
        if self.cancellation_requested and not self.is_locked():
            db.session.delete(self)
            db.session.commit()
            return True
        return False
    
    def __repr__(self):
        return f"Reservation('{self.date}', '{self.guests}', '{self.menu_choice}', '{self.total_price}')"