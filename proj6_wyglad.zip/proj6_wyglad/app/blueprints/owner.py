from flask import render_template, url_for, flash, redirect, request, Blueprint
from app import db
from app.models import Reservation
from app.decorators import role_required
from flask_login import login_required, current_user
from datetime import datetime

owner_bp = Blueprint('owner', __name__, template_folder='templates')

@owner_bp.route('/owner_panel')
@login_required
@role_required('owner')
def owner_panel():
    if current_user.role != 'owner':
        flash('Nie masz uprawnień do wejścia na tę stronę.', 'danger')
        return redirect(url_for('index'))
    
    reservations = Reservation.query.all()
    current_time = datetime.now()
    return render_template('owner.html', reservations=reservations, current_time=current_time)

@owner_bp.route('/confirm_cancellation/<int:reservation_id>', methods=['POST'])
@login_required
@role_required('owner')
def confirm_cancellation(reservation_id):
    reservation = Reservation.query.get_or_404(reservation_id)

    if request.method == 'POST':
        if reservation.confirm_cancellation():
            flash('Rezerwacja została pomyślnie anulowana.', 'success')
        else:
            flash('Nie można anulować tej rezerwacji.', 'danger')

    reservations = Reservation.query.all()
    current_time = datetime.now()
    return render_template('owner.html', reservations=reservations, current_time=current_time)



@owner_bp.route('/modify_reservation/<int:reservation_id>', methods=['GET', 'POST'])
@login_required
@role_required('owner')
def modify_reservation(reservation_id):
    reservation = Reservation.query.get_or_404(reservation_id)

    current_time = datetime.now()
    if reservation.date < current_time:
        flash('Możesz zmodyfikować jedynie przyszłe rezerwacje.', 'danger')
        return redirect(url_for('owner.owner_panel'))
    
    if request.method == 'POST':
        try:
            reservation.date = datetime.strptime(request.form['date'], '%Y-%m-%dT%H:%M')
        except ValueError:
            flash('Niepoprawna data', 'danger')
            return redirect(url_for('owner.modify_reservation', reservation_id=reservation.id))

        # Update other fields
        reservation.guests = request.form['guests']
        reservation.menu_choice = request.form['menu_choice']
        
        # Commit changes to the database
        db.session.commit()
        # flash('Reservation updated successfully', 'success')
        return redirect(url_for('owner.owner_panel'))

    return render_template('modify_reservation.html', reservation=reservation)
