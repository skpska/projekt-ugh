from app import app, db
from app.models import Restaurant, User
from werkzeug.security import generate_password_hash

with app.app_context():
    db.create_all()
    
    restaurant1 = Restaurant(
        name='CK Antares', 
        location='Kraków, ul. Krakowska 94', 
        menu1='Rosół, kotlet schabowy, ziemniaki/frytki, tiramisu.', 
        menu2='Śledź po japońsku, rosół, kotlet schabowy, ziemniaki/frytki, tiramisu, puchar lodowy z owocami.',
        capacity=150,
        menu1_price = 150.0,
        menu2_price = 200.0)
    restaurant2 = Restaurant(
        name='Pallatia', 
        location='Kraków Zielonki, ul. Krakowskie Przedmieście 201', 
        menu1='Zupa pomidorowa, kotlet devolay, ziemniaki, makowiec. ', 
        menu2='Carpaccio z buraka z kozim serem, zupa pomidorowa, kotlet devolay, ziemniaki, kapusta zasmażana, makowiec, ciasto marchewkowe.',
        capacity=250,
        menu1_price = 130.0,
        menu2_price = 240.0)
    restaurant3 = Restaurant(
        name='Hotel Witek', 
        location='Kraków, ul. Handlowców 14', 
        menu1='Krem z dyni, kotlet devolay, kluski, szarlotka.',
        menu2='Mini tatar z łososia z grzanką, krem z dyni, kotlet devolay, kluski, mizeria, puchar lodowy z owocami, szarlotka.',
        capacity=130,
        menu1_price = 200.0,
        menu2_price = 400.0)
    restaurant4 = Restaurant(
        name='RestoClub ARKA', 
        location='Kraków, ul. Klemensiewicza 3', 
        menu1='Zupa ogórkowa, kotlet schabowy, buraczki, sernik.', 
        menu2='Pieczywo czosnkowe, zupa ogórkowa, kotlet schabowy, buraczki, sernik, szarlotka.',
        capacity=300,
        menu1_price = 180.0,
        menu2_price = 290.0)
    restaurant5 = Restaurant(
        name='Garden Square Hotel', 
        location='Kraków, ul. Sucha 1D', 
        menu1='Barszcz czerwony z uszkami, ryba, deser czekoladowy. ', 
        menu2='Śledź, barszcz czerwony z uszkami, ryba, deser czekoladowy, panacotta.',
        capacity=110,
        menu1_price = 210.0,
        menu2_price = 340.0)
    restaurant6 = Restaurant(
        name='Hotel Centrum Business', 
        location='Kraków, ul. Osiedle Centrum E', 
        menu1='Krem z dyni, kotlet devolay, kluski, szarlotka.', 
        menu2='Mini tatar z łososia z grzanką, krem z dyni, kotlet devolay, kluski, mizeria, puchar lodowy z owocami, szarlotka.',
        capacity=250, 
        menu1_price = 170.0,
        menu2_price = 260.0)
    restaurant7 = Restaurant(
        name='Zajazd Polesie', 
        location='Kraków Zielonki ul. Młyńska 29', 
        menu1='Zupa ogórkowa, kotlet schabowy, buraczki, sernik.', 
        menu2='Pieczywo czosnkowe, zupa ogórkowa, kotlet schabowy, buraczki, sernik, szarlotka.',
        capacity=170, 
        menu1_price = 165.0,
        menu2_price = 310.0)
    restaurant8 = Restaurant(
        name='Hotel Lenart', 
        location='Kraków, ul. Narutowicza 1', 
        menu1='Zupa ogórkowa, kotlet schabowy, buraczki, sernik. ', 
        menu2='Pieczywo czosnkowe, zupa ogórkowa, kotlet schabowy, buraczki, sernik, szarlotka.',
        capacity=300,
        menu1_price = 140.0,
        menu2_price = 300.0)
    restaurant9 = Restaurant(
        name='Restauracja Pod Kopcem', 
        location='Kraków, al. Waszyngtona 1', 
        menu1='Rosół, kotlet schabowy, ziemniaki/frytki, tiramisu. ', 
        menu2='Śledź po japońsku, rosół, kotlet schabowy, ziemniaki/frytki, tiramisu, puchar lodowy z owocami.',
        capacity=140,
        menu1_price = 170.0,
        menu2_price = 230.0)
    restaurant10 = Restaurant(
        name='Willa Fryderyka', 
        location='Kraków, ul. Kazimierza Wielkiego 105', 
        menu1='Zupa pomidorowa, kotlet devolay, ziemniaki, makowiec. ', 
        menu2='Carpaccio z buraka z kozim serem, zupa pomidorowa, kotlet devolay, ziemniaki, kapusta zasmażana, makowiec, ciasto marchewkowe.',
        capacity=85,
        menu1_price = 220.0,
        menu2_price = 320.0)

    
    db.session.add(restaurant1)
    db.session.add(restaurant2)
    db.session.add(restaurant3)
    db.session.add(restaurant4)
    db.session.add(restaurant5)
    db.session.add(restaurant6)
    db.session.add(restaurant7)
    db.session.add(restaurant8)
    db.session.add(restaurant9)
    db.session.add(restaurant10)

    hashed_password = generate_password_hash('password123', method='pbkdf2')

    # dodanie właściciela i admina
    owner_password = generate_password_hash('owner', method='pbkdf2')
    owner = User(username='owner', email='owner@example.com', password=owner_password, role='owner')
    db.session.add(owner)

    admin_password = generate_password_hash('admin', method='pbkdf2')
    admin = User(username='admin', email='admin@example.com', password=admin_password, role='admin')
    db.session.add(admin)

    db.session.commit()
